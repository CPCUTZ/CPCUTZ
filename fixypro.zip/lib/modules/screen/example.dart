import 'package:flutter/material.dart';

void main() => runApp(Example());

class Example extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text("Ejemplo Básico de Flutter")),
        body: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Bienvenido al ejemplo básico",
                  style: TextStyle(fontSize: 20)),
              SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(Icons.star, color: Colors.blue, size: 30),
                  Icon(Icons.star, color: Colors.red, size: 30),
                  Icon(Icons.star, color: Colors.green, size: 30),
                  Spacer(),
                ],
              ),
              SizedBox(height: 20),
              FormExample(), // Nuestro widget de formulario
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: () {},
                    child: Text("ElevatedButton"),
                  ),
                  TextButton(
                    onPressed: () {},
                    child: Text("TextButton"),
                  ),
                ],
              ),
              SizedBox(height: 20),
              Image.network('https://via.placeholder.com/150'),
            ],
          ),
        ),
      ),
    );
  }
}

// Widget del formulario
class FormExample extends StatefulWidget {
  @override
  _FormExampleState createState() => _FormExampleState();
}

class _FormExampleState extends State<FormExample> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          TextFormField(
            decoration: InputDecoration(labelText: 'Nombre'),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Por favor ingresa tu nombre';
              }
              return null;
            },
          ),
          SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Formulario válido')),
                );
              }
            },
            child: Text('Enviar'),
          ),
        ],
      ),
    );
  }
}
