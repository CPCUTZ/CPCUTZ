import 'package:flutter/material.dart';
import 'package:fixy_pro/modules/screen/create_account.dart';
import 'package:fixy_pro/modules/screen/example.dart';
import 'package:fixy_pro/modules/screen/main_menu_provider.dart';

void main() async {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

//flutter pub get
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/main_menu_provider.dart',
      routes: {
        '/': (context) => const CreateAccount(),
        '/main_menu_provider.dart': (context) => MainMenuProvider(),
        '/example.dart': (context) => Example(),
      },
    );
  }
}
